/**
 *
 * @author tugba
 */
public interface ICalisma 
{
    void calis();
}
