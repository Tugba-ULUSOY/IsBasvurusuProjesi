/**
 *
 * @author tugba
 */
public class MakineMuhendisi implements IMuhendis, ICalisma
{   
    private boolean askerlik;
    private boolean adli_sicil;

    public MakineMuhendisi(boolean askerlik, boolean adli_sicil) 
    {
        this.askerlik = askerlik;
        this.adli_sicil = adli_sicil;
    }
    
    @Override
    public void calis() 
    {
        System.out.println("Makine mühendisi çalışmaya başladı...");
    }
    
    @Override
    public void askerlik_durumu_sorgula() 
    {
        if(askerlik)
        {
             System.out.println("Askerliğimi Yaptım.");
        }
        else
        {
             System.out.println("Askerliğimi Henüz Yapmadım.");
        }
            
    }

    @Override
    public String mezuniyet_ortalamasi(double derece) 
    {
        return "Ortalama: " + derece;
    }

    @Override
    public void adli_sicil_sorgula() 
    {
        if(adli_sicil)
        {
            System.out.println("Adli Sicil Kaydım Bulunuyor.");
        }
        else
        {
            System.out.println("Herhangi Bir Adli Sicil Kaydım Bulunmuyor.");
        }
    }

    @Override
    public void is_tecrubesi(String[] array) 
    {
        if(array.length == 0)
        {
            System.out.println("Herhangi Bir İş Tecrübem Bulunmuyor.");
        }
        else
        {
            System.out.println("Makine Mühendisi Olarak Şu Şirketlerde Çalıştım:");
         
            for(String s: array)
            {
                System.out.println(s);
            }
        }
    }
    
    public void referans_getir(String[] array)
    {
        if(array.length == 0)
        {
            System.out.println("Herhangi Bir Referansım Bulunmuyor.");
        }
        else
        {
            System.out.println("Referanslarım:");
            
            for(String s: array)
            {
                System.out.println(s);
            } 

        }
        
    }
    
}
