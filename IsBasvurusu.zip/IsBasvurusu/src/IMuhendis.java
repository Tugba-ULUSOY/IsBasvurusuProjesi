/**
 *
 * @author tugba
 */
public interface IMuhendis 
{    
    // interface den obje oluşturulamadığı için public, private gibi erişim belirleyicileri koymamıza gerek kalmıyor.
    
    void askerlik_durumu_sorgula(); // Bu metodların içine bir kod bloğu yazmayacağız. Eğer class larda bu metodları tanımlayacaksan(implement edeceksen) bu formda tanımlaman gerekiyor anlamındadır.
    String mezuniyet_ortalamasi(double derece);
    void adli_sicil_sorgula();
    void is_tecrubesi(String[] array);
    
    
    
}
