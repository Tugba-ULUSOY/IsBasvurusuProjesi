/**
 *
 * @author tugba
 */
public class PcMuhendis implements IMuhendis
{
    // Class ımıza ait alanlar(özellikler) tanımladık iki tane
    private boolean askerlik; // Askerliği yaptık mı yapmadık mı true false dönücek.
    private boolean adli_sicil; 

    public PcMuhendis(boolean askerlik, boolean adli_sicil) 
    {
        this.askerlik = askerlik;
        this.adli_sicil = adli_sicil;
    }
    
    
    
    // interface in metodlarını kullanabilmek için (insert code -> implement method) yaptık.
    @Override
    public void askerlik_durumu_sorgula() 
    {
        if(askerlik)
        {
            System.out.println("Askerliğimi Yaptım.");
        }
        else
        {
            System.out.println("Askerliğimi Henüz Yapmadım.");
        }
    }

    @Override
    public String mezuniyet_ortalamasi(double derece) 
    {
        // girilen double dereceye göre bir string döndürmemiz gerekiyor.
        return "Ortalamam: " + derece;
    }

    @Override
    public void adli_sicil_sorgula() 
    {
        if(adli_sicil)
        {
            System.out.println("Adli Sicil Kaydım Bulunuyor.");
        }
        else
        {
            System.out.println("Herhangi Bir Adli Sicil Kaydım Bulunmuyor."); // Sicil temiz
        }
    }

    @Override
    public void is_tecrubesi(String[] array) 
    {
        if(array.length == 0)
        {
            System.out.println("Herhangi Bir İş Tecrübem Bulunmuyor.");
        }
        else
        {
            System.out.println("Bilgisayar Mühendisi Olarak Şu Şirketlerde Çalıştım:");
                       
            for(String s: array)
            {
                System.out.println(s);
            }                
        }
    }        
}
